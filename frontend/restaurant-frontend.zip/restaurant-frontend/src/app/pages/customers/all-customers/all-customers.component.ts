import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-customers',
  templateUrl: './all-customers.component.html',
  styleUrls: ['./all-customers.component.less']
})
export class AllCustomersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

export interface Customer {
  id?: number;
  firstName: string;
  lastName: string;
  phoneNumber: string;
}

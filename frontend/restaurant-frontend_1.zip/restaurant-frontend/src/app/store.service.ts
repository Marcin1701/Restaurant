import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { OrderResponse } from 'src/model/response/orderResponse';

@Injectable({
  providedIn: 'root'
})
export class StoreService {

  orders: OrderResponse[] = [];

  constructor(private orde) { 
  
  }

}

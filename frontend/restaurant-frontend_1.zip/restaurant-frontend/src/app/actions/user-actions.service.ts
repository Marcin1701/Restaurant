import { Injectable } from '@angular/core';
import { OrderResponse } from 'src/model/response/orderResponse';
import { StoreService } from '../store.service';

@Injectable({
  providedIn: 'root'
})
export class UserActionsService {

  constructor(private store: StoreService) { }

  getAllOrders(): OrderResponse[] {
      
  }
}

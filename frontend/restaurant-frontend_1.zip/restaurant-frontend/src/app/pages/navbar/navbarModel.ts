export interface NavbarModel {
  navbarName: string;
  navbarContent: string[];
}

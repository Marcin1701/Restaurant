import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class IngredientRestCrudService {

  constructor() { }
}

export interface MealRequest {
    name: string;
}
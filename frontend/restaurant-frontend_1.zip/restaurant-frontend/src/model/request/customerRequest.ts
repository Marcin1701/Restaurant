export interface CustomerRequest {
    firstName: string;
    
    lastName: string;

    phoneNumber: string;
}
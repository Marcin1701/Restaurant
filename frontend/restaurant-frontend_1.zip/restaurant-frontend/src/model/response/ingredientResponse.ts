export interface IngredientResponse {
    id: string;

    name: string;
}
export interface CustomerResponse {
    id: number;

    firstName: string;

    lastName: string;

    phoneNumber: string;
}
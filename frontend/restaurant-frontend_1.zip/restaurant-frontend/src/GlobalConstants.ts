export class GlobalConstants {
    public static imageUrl: string = "https://images.pexels.com/photos/3201920/pexels-photo-3201920.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940";
}